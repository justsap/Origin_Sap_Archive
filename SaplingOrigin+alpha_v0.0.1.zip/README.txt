Datapack Created by JustSap!

Socials:
https://www.youtube.com/@JustSaps

@justsap_ on Twitter & Instagram

-----------------------------------
Information:
		This datapack adds my personal origin, "Sapling"! This of course requires the Origins Mod. 
	This origin has the following abilities:

	+ Poison Ivy [Toggled]: Whenever you punch a player or entity with this toggled, it poisons the target. This also makes it so any entity or player that hits you also gets poisoned (even if its not toggled)

	+ Grounded Roots [Activate]: You can protect yourself by summoning a bush-like structure and give yourself a bunch of defensive potion effects. This may seem overpowered, however it takes away 5 experience levels.

	+ Phasing Leaves: You can move faster when phasing through leaves

	+ Autotroph & Water: You can't eat food, however you get saturation from being in the sun or by drinking water

	+ Burnable: You can't handle hot biomes and fire deals more damage to you

	+ No Shields

-----------------------------------

Please Credit Me (justsap) whenever you're showcasing or redistributing the mod!

DO NOT REMOVE THIS TEXT FILE FROM PACK!